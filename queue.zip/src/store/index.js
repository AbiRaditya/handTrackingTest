import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    queue: [],
    queue2: [],
    currentPage: 1,
    totalPage: null,
    totalItem: null,
  },
  mutations: {
    SET_QUEUE(state, res) {
      let labels = [];
      let data = [];
      let objTemplate = {};
      let count = 0;
      res.forEach((item) => {
        labels.push(item.tujuanRujukan.nama);
      });
      console.log(labels);
      labels.forEach((item) => {
        res.forEach((el) => {
          if (el.tujuanRujukan.nama === item) {
            if (objTemplate.label == item) {
              if (count < 7) {
                objTemplate.children.push(el);
              }
              count++;
            } else {
              console.log(count == 5);

              objTemplate = {
                label: item,
                children: [el],
                mode: "span",
                html: false,
              };

              if (count == 5) {
                data.push(objTemplate);
              }
              count += 2;
            }
          }
        });
        if (count <= 7) {
          data.push(objTemplate);
        }

        objTemplate = {};
      });
      console.log(data);
      state.queue = data;
    },
    SET_QUEUE2(state, res) {
      let labels = [];
      let data = [];
      let objTemplate = {};
      let count = 0;
      // let manipulatedData = [];

      res.forEach((item) => {
        labels.push(item.tujuanRujukan.nama);
      });
      console.log(labels);
      labels.forEach((item) => {
        res.forEach((el) => {
          if (el.tujuanRujukan.nama === item) {
            if (objTemplate.label == item) {
              if (count < 7) {
                objTemplate.children.push(el);
              }
              count++;
            } else {
              objTemplate = {
                label: item,
                children: [el],
                mode: "span",
                html: false,
              };

              if (count == 5) {
                data.push(objTemplate);
              }
              count += 2;
            }
          }
        });
        if (count <= 7) {
          data.push(objTemplate);
        }

        objTemplate = {};
      });
      console.log(data);
      state.queue2 = data;
    },
    SET_TOTAL_PAGE(state, res) {
      state.totalPage = res;
    },
    SET_TOTAL_ITEM(state, res) {
      state.totalItem = res;
    },
  },
  actions: {
    getQueueData({ commit }) {
      const data = [
        {
          id: 1,
          nama: "First Impression",
          tujuanRujukan: {
            nama: "Rawat Test",
          },
          jadwal: {
            jamMulai: "08:00",
            jamSelesai: "10:00",
          },
          room: {
            name: "Bone Denistometry",
            floor: "1",
          },
          queueNoFormatted: "W0001",
        },
        {
          id: 2,
          nama: "Second Impression",
          tujuanRujukan: {
            nama: "Jantung 2",
          },
          jadwal: {
            jamMulai: "08:00",
            jamSelesai: "10:00",
          },
          room: {
            name: "Bone Denistometry",
            floor: "1",
          },
          queueNoFormatted: "W0001",
        },
        {
          id: 21,
          nama: "Second Impression",
          tujuanRujukan: {
            nama: "Jantung",
          },
          jadwal: {
            jamMulai: "08:00",
            jamSelesai: "10:00",
          },
          room: {
            name: "Bone Denistometry",
            floor: "1",
          },
          queueNoFormatted: "W0001",
        },
        {
          id: 22,
          nama: "Second Impression",
          tujuanRujukan: {
            nama: "Jantung",
          },
          jadwal: {
            jamMulai: "08:00",
            jamSelesai: "10:00",
          },
          room: {
            name: "Bone Denistometry",
            floor: "1",
          },
          queueNoFormatted: "W0001",
        },
        {
          id: 3,
          nama: "Third Impression",
          tujuanRujukan: {
            nama: "Kejiwaan",
          },
          jadwal: {
            jamMulai: "08:00",
            jamSelesai: "10:00",
          },
          room: {
            name: "Bone Denistometry",
            floor: "1",
          },
          queueNoFormatted: "W0001",
        },
        {
          id: 4,
          nama: "Fourth Impression",
          tujuanRujukan: {
            nama: "Radiology",
          },
          jadwal: {
            jamMulai: "08:00",
            jamSelesai: "10:00",
          },
          room: {
            name: "Bone Denistometry",
            floor: "1",
          },
          queueNoFormatted: "W0001",
        },
        {
          id: 5,
          nama: "Fifth Impression",
          tujuanRujukan: {
            nama: "Rawat Test",
          },
          jadwal: {
            jamMulai: "08:00",
            jamSelesai: "10:00",
          },
          room: {
            name: "Bone Denistometry",
            floor: "1",
          },
          queueNoFormatted: "W0001",
        },
        {
          id: 7,
          nama: "Fifth Impression",
          tujuanRujukan: {
            nama: "Rawat Test",
          },
          jadwal: {
            jamMulai: "08:00",
            jamSelesai: "10:00",
          },
          room: {
            name: "Bone Denistometry",
            floor: "1",
          },
          queueNoFormatted: "W0001",
        },
      ];
      commit("SET_TOTAL_PAGE", Math.ceil(data.length / 7));
      commit("SET_TOTAL_ITEM", data.length);
      commit("SET_QUEUE", data);
    },
  },
  modules: {},
});
