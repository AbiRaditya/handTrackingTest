<template>
  <div class="flex">
    <!-- <div v-for="q in queue" :key="q.id">{{ q.nama }}</div> -->
    <!-- <table>
      <thead>
        <tr class="bg-blue-900 text-white text-left">
          <th>Floor</th>
          <th>Name</th>
          <th>Schedule</th>
          <th>Queue</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="q in queue" :key="q.id">
          <td>{{ q.room.floor }}F</td>
          <td>{{ q.nama }}</td>
          <td>{{ q.jadwal.jamMulai }} - {{ q.jadwal.jamSelesai }}</td>
          <td>{{ q.queueNoFormatted }}</td>
        </tr>
      </tbody>
    </table> -->
    <div style="width: 50%">
      <vue-good-table
        :columns="columns"
        :rows="queue"
        :sort-options="{
          enabled: false,
        }"
        :group-options="{
          enabled: true,
        }"
      />
    </div>
    <div style="width: 50%">
      <vue-good-table
        :columns="columns"
        :rows="queue"
        :sort-options="{
          enabled: false,
        }"
        :group-options="{
          enabled: true,
        }"
      />
    </div>
    <footer-q></footer-q>
  </div>
</template>

<script>
import { mapActions, mapState } from "vuex";
import FooterQ from "../components/FooterQueue.vue";
export default {
  name: "Queue",
  components: {
    FooterQ,
  },
  computed: {
    ...mapState({
      queue: (state) => state.queue,
    }),
  },
  methods: {
    ...mapActions(["getQueueData"]),
    schedule(rowObj) {
      return `${rowObj.jadwal.jamMulai} - ${rowObj.jadwal.jamSelesai}`;
    },
  },
  mounted() {
    this.getQueueData();
  },
  data() {
    return {
      columns: [
        {
          label: "Floor",
          field: "room.floor",
        },
        {
          label: "Name",
          field: "nama",
        },
        {
          label: "Schedule",
          type: "String",
          field: this.schedule,
        },
        {
          label: "Queue",
          field: "queueNoFormatted",
        },
      ],
    };
  },
};
</script>

<style></style>
